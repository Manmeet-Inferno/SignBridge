// Listen for installation
chrome.runtime.onInstalled.addListener(function() {
  // Initialize storage
  chrome.storage.local.set({
    translationEnabled: false,
    captureMode: 'self',
    showDebug: false,
    availableSignWords: []
  });

  // Scan for available sign language videos
  scanSignVideos();
});

// Function to scan for available sign language videos
function scanSignVideos() {
  // This is a list of words based on the sign_words directory content
  const availableWords = [
    'accept', 'accident', 'actor', 'adjust', 'admire', 'adult', 'ago', 'agreement', 'amazing',
    'and', 'another', 'back', 'bathroom', 'battery', 'bear', 'bird', 'birthday', 'botton',
    'can', 'come', 'complete', 'conquer', 'culture', 'deaf', 'demonstrate', 'develop',
    'doctor', 'drama', 'drop', 'environment', 'everyday', 'flatter', 'friend', 'goodbye',
    'habit', 'hampburger', 'heaven', 'hello', 'i', 'jewelry', 'learn', 'memorize', 'motorcycle',
    'my', 'name', 'picture', 'popular', 'presiden', 'real', 'scientist', 'service', 'shoot',
    'signapse', 'signlanguage', 'smoking', 'spray', 'stairs', 'subway', 'sympathy', 'talk',
    'thankyou', 'this', 'to', 'want', 'whistle', 'willing', 'with', 'year', 'yourself', 'zero'
  ];

  chrome.storage.local.set({ availableSignWords: availableWords });
}

// Listen for tab updates
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.status === 'complete' && tab.url.includes('meet.google.com')) {
    // Check if translation is enabled
    chrome.storage.local.get(['translationEnabled', 'captureMode', 'showDebug'], function(result) {
      if (result.translationEnabled) {
        // Notify the content script to start translation
        chrome.tabs.sendMessage(tabId, {
          action: 'toggleTranslation',
          enabled: true,
          captureMode: result.captureMode,
          showDebug: result.showDebug
        });
      }
    });
  }
});

// Listen for word recognition messages
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'wordRecognized') {
    handleRecognizedWord(request.word, sender.tab.id);
    return true;
  }
});

// Function to handle recognized words
function handleRecognizedWord(word, tabId) {
  console.log('Handling recognized word:', word);
  chrome.storage.local.get(['availableSignWords'], function(result) {
    const availableWords = result.availableSignWords || [];
    
    // Clean and normalize the word
    const cleanWord = word.toLowerCase().trim();
    
    // Check if we have a sign video for this word
    if (availableWords.includes(cleanWord)) {
      console.log('Found matching sign video for word:', cleanWord);
      // Send message to content script to show the sign video
      chrome.tabs.sendMessage(tabId, {
        action: 'showSignVideo',
        word: cleanWord
      });
    } else {
      console.log('No sign video available for word:', cleanWord);
    }
  });
}