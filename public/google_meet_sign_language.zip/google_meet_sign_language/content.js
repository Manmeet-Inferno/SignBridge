let audioContext = null;
let mediaSource = null;
let analyser = null;
let recognition = null;
let translationEnabled = false;
let signLanguageContainer = null;
let currentVideoElement = null;
let videoCache = new Map(); // Cache for loaded videos
let videoQueue = []; // Queue for videos to play
let isPlaying = false; // Flag to track if a video is currently playing
let currentlyProcessingWords = new Set(); // Set to track words being processed
let captureMode = 'self'; // Default capture mode
let showDebug = false; // Whether to show debug info
let debugInfo = null; // Debug info element
let audioStream = null; // The audio stream

// Available words for sign language
const availableWords = [
  'accept',
  'accident',
  'actor',
  'adjust',
  'admire',
  'adult',
  'ago',
  'agreement',
  'amazing',
  'and',
  'another',
  'back',
  'bathroom',
  'battery',
  'bear',
  'bird',
  'birthday',
  'botton',
  'can',
  'come',
  'complete',
  'conquer',
  'culture',
  'deaf',
  'demonstrate',
  'develop',
  'doctor',
  'drama',
  'drop',
  'environment',
  'everyday',
  'flatter',
  'friend',
  'goodbye',
  'habit',
  'hampburger',
  'heaven',
  'hello',
  'i',
  'jewelry',
  'learn',
  'memorize',
  'motorcycle',
  'my',
  'name',
  'picture',
  'popular',
  'presiden',
  'real',
  'scientist',
  'service',
  'shoot',
  'signapse',
  'signlanguage',
  'smoking',
  'spray',
  'stairs',
  'subway',
  'sympathy',
  'talk',
  'thankyou',
  'this',
  'to',
  'want',
  'whistle',
  'willing',
  'with',
  'year',
  'yourself',
  'zero'
];

// Listen for messages from the popup or background script
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'toggleTranslation') {
    if (request.enabled) {
      captureMode = request.captureMode;
      showDebug = request.showDebug;
      startTranslation();
    } else {
      stopTranslation();
    }
    return true;
  } else if (request.action === 'updateOptions') {
    captureMode = request.captureMode;
    showDebug = request.showDebug;
    updateDebugVisibility();
    return true;
  } else if (request.action === 'showSignVideo') {
    queueWord(request.word);
    return true;
  }
});

// Create debug info element
function createDebugInfo() {
  debugInfo = document.createElement('div');
  debugInfo.id = 'gmt-debug-info';
  debugInfo.style.cssText = `
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(0,0,0,0.8);
    color: white;
    padding: 10px 20px;
    border-radius: 8px;
    font-family: Arial, sans-serif;
    font-size: 14px;
    z-index: 9999;
    display: ${showDebug ? 'block' : 'none'};
  `;
  document.body.appendChild(debugInfo);
  return debugInfo;
}

function updateDebugVisibility() {
  if (debugInfo) {
    debugInfo.style.display = showDebug ? 'block' : 'none';
  }
}

// Function to preload videos
async function preloadVideos() {
  console.log('Initializing video system...');
  
  // Clear existing cache
  videoCache.clear();
  let loadedCount = 0;
  
  // Create a map of normalized words to actual file paths
  const wordToPathMap = new Map();
  
  // First, verify which videos exist
  for (const word of availableWords) {
    try {
      // Try different file name patterns
      const patterns = [
        `${word}.mp4`,
        `${word} .mp4`,
        `${word}- Trim.mp4`,
        `${word.charAt(0).toUpperCase() + word.slice(1)}.mp4`
      ];
      
      let videoPath = null;
      
      for (const pattern of patterns) {
        try {
          const path = chrome.runtime.getURL(`sign_words/${pattern}`);
          const response = await fetch(path, { method: 'HEAD' });
          if (response.ok) {
            videoPath = path;
            break;
          }
        } catch (e) {
          // Continue to next pattern
        }
      }
      
      if (videoPath) {
        wordToPathMap.set(word, videoPath);
        console.log(`Found video for ${word}: ${videoPath}`);
      }
    } catch (error) {
      console.error(`Failed to find video for ${word}:`, error);
    }
  }
  
  // Update available words to only include those with videos
  const availableWordsWithVideos = Array.from(wordToPathMap.keys());
  console.log('Available words with videos:', availableWordsWithVideos);
  
  updateDebugInfo(`Found ${availableWordsWithVideos.length} available videos`);
  
  return availableWordsWithVideos.length;
}

// Function to cleanup resources
function cleanupResources() {
  console.log('Cleaning up resources...');
  
  // Stop recognition first
  if (recognition) {
    try {
      recognition.stop();
      recognition.onresult = null;
      recognition.onerror = null;
      recognition.onend = null;
      recognition.onstart = null;
      recognition.started = false;
    } catch (e) {
      console.error('Error stopping recognition:', e);
    }
    recognition = null;
  }

  // Stop audio stream if it exists
  if (audioStream) {
    audioStream.getTracks().forEach(track => track.stop());
    audioStream = null;
  }

  // Clear audio context
  if (audioContext) {
    try {
      if (mediaSource) {
        mediaSource.disconnect();
      }
      if (analyser) {
        analyser.disconnect();
      }
      audioContext.close();
    } catch (e) {
      console.error('Error closing audio context:', e);
    }
    audioContext = null;
    mediaSource = null;
    analyser = null;
  }
  
  // Clear video queue and cache
  videoQueue = [];
  isPlaying = false;
  if (currentVideoElement) {
    try {
      currentVideoElement.pause();
      currentVideoElement.removeAttribute('src');
      currentVideoElement.load();
    } catch (e) {
      console.error('Error cleaning video element:', e);
    }
  }
  
  // Clear video cache
  try {
    for (const url of videoCache.values()) {
      URL.revokeObjectURL(url);
    }
    videoCache.clear();
  } catch (e) {
    console.error('Error clearing video cache:', e);
  }
  
  // Remove debug info
  if (debugInfo) {
    try {
      document.body.removeChild(debugInfo);
    } catch (e) {
      console.error('Error removing debug info:', e);
    }
    debugInfo = null;
  }
  
  // Remove word tracker
  const wordTracker = document.getElementById('word-tracker');
  if (wordTracker) {
    wordTracker.remove();
  }
  
  // Remove sign language container
  if (signLanguageContainer) {
    try {
      document.body.removeChild(signLanguageContainer);
    } catch (e) {
      console.error('Error removing sign language container:', e);
    }
    signLanguageContainer = null;
  }
  
  // Remove word list
  const wordList = document.getElementById('word-list');
  if (wordList) {
    wordList.remove();
  }
  
  console.log('Resources cleaned up');
}

// Request microphone permission
async function requestMicrophonePermission() {
  try {
    audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    return true;
  } catch (error) {
    console.error('Error accessing microphone:', error);
    updateDebugInfo('Error accessing microphone. Please grant permission.');
    return false;
  }
}

// Start the translation process
async function startTranslation() {
  if (translationEnabled) {
    return;
  }

  translationEnabled = true;
  console.log('Starting translation...');
  
  // Create UI elements
  if (!debugInfo) {
    createDebugInfo();
  }
  updateDebugVisibility();
  
  if (!signLanguageContainer) {
    createSignLanguageContainer();
  }
  ensureSignLanguageContainerVisible();
  
  // Preload videos
  updateDebugInfo('Loading sign language videos...');
  await preloadVideos();
  
  // Request microphone permission if needed
  if (captureMode === 'self' || captureMode === 'all') {
    updateDebugInfo('Requesting microphone permission...');
    const micPermission = await requestMicrophonePermission();
    if (!micPermission) {
      updateDebugInfo('Microphone permission denied');
      return;
    }
  }
  
  // Initialize speech recognition
  initializeSpeechRecognition();
  
  updateDebugInfo('Sign language translation active');
}

// Stop the translation process
function stopTranslation() {
  if (!translationEnabled) {
    return;
  }
  
  translationEnabled = false;
  console.log('Stopping translation...');
  
  cleanupResources();
  
  chrome.storage.local.set({ translationEnabled: false });
}

// Make sure the sign language container is visible
function ensureSignLanguageContainerVisible() {
  if (!signLanguageContainer) return;
  
  signLanguageContainer.style.display = 'flex';
  
  // Position the container in the bottom right of the meeting view
  const meetingView = document.querySelector('.zWfAib'); // Google Meet's main video container
  
  if (meetingView) {
    // Position relative to the meeting view
    const rect = meetingView.getBoundingClientRect();
    signLanguageContainer.style.top = `${rect.top + 20}px`;
    signLanguageContainer.style.right = `${window.innerWidth - rect.right + 20}px`;
    signLanguageContainer.style.bottom = 'auto';
    signLanguageContainer.style.left = 'auto';
  } else {
    // Default position if meeting view not found
    signLanguageContainer.style.top = 'auto';
    signLanguageContainer.style.right = '20px';
    signLanguageContainer.style.bottom = '20px';
    signLanguageContainer.style.left = 'auto';
  }
}

// Create the container for sign language videos
function createSignLanguageContainer() {
  signLanguageContainer = document.createElement('div');
  signLanguageContainer.id = 'gmt-sign-language-container';
  signLanguageContainer.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 300px;
    height: 200px;
    background: rgba(0,0,0,0.7);
    border-radius: 8px;
    overflow: hidden;
    z-index: 9998;
    display: flex;
    justify-content: center;
    align-items: center;
    box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    border: 1px solid rgba(255,255,255,0.2);
  `;
  
  document.body.appendChild(signLanguageContainer);
  
  // Add a close button
  const closeButton = document.createElement('button');
  closeButton.style.cssText = `
    position: absolute;
    top: 5px;
    right: 5px;
    width: 24px;
    height: 24px;
    background: rgba(0,0,0,0.5);
    border: none;
    border-radius: 50%;
    color: white;
    font-size: 14px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    z-index: 9999;
  `;
  closeButton.textContent = '×';
  closeButton.addEventListener('click', stopTranslation);
  signLanguageContainer.appendChild(closeButton);
  
  return signLanguageContainer;
}

// Initialize speech recognition
function initializeSpeechRecognition() {
  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
    updateDebugInfo('Speech recognition not supported');
    return;
  }
  
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SpeechRecognition();
  
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = 'en-US';
  
  recognition.onstart = function() {
    updateDebugInfo('Speech recognition started');
  };
  
  recognition.onresult = function(event) {
    if (!translationEnabled) return;
    
    for (let i = event.resultIndex; i < event.results.length; i++) {
      if (event.results[i].isFinal) {
        const transcript = event.results[i][0].transcript.trim();
        processSpeechResult(transcript);
      }
    }
  };
  
  recognition.onerror = function(event) {
    console.error('Speech recognition error:', event.error);
    updateDebugInfo(`Speech recognition error: ${event.error}`);
    
    // Restart recognition if it crashes
    if (event.error === 'network' || event.error === 'aborted') {
      setTimeout(() => {
        if (translationEnabled && !recognition.started) {
          recognition.start();
        }
      }, 1000);
    }
  };
  
  recognition.onend = function() {
    // Restart if translation is still enabled
    if (translationEnabled) {
      setTimeout(() => {
        if (translationEnabled && !recognition.started) {
          recognition.start();
        }
      }, 500);
    }
  };
  
  // Start recognition
  try {
    recognition.start();
    recognition.started = true;
  } catch (e) {
    console.error('Error starting speech recognition:', e);
    updateDebugInfo('Error starting speech recognition');
  }
  
  // Also listen for Google Meet captions
  observeMeetCaptions();
}

// Process speech recognition results
function processSpeechResult(transcript) {
  if (!translationEnabled) return;
  
  console.log('Speech recognized:', transcript);
  updateDebugInfo(`Speech: ${transcript}`);
  
  // Split transcript into words
  const words = transcript.toLowerCase().split(/\s+/).filter(word => word.length > 0);
  
  // Process words
  processRecognizedWords(words);
}

// Listen for Google Meet captions
function observeMeetCaptions() {
  // The container for Google Meet captions
  const captionSelector = '.a4cQT';
  
  // Function to check for caption elements
  function checkForCaptions() {
    const captionElements = document.querySelectorAll(captionSelector);
    
    if (captionElements.length > 0) {
      // Set up observers for each caption element
      captionElements.forEach(element => {
        const observer = new MutationObserver(mutations => {
          mutations.forEach(mutation => {
            if (mutation.type === 'childList' || mutation.type === 'characterData') {
              const text = element.textContent.trim();
              if (text && text.length > 0) {
                // Check if we should process this caption based on captureMode
                const isFromSelf = element.closest('.S9745b'); // Self caption has this container
                
                if ((captureMode === 'self' && isFromSelf) || 
                    (captureMode === 'others' && !isFromSelf) || 
                    captureMode === 'all') {
                  processCaptionText(text);
                }
              }
            }
          });
        });
        
        observer.observe(element, { 
          childList: true, 
          characterData: true,
          subtree: true 
        });
      });
      
      updateDebugInfo('Caption observer started');
    } else {
      // If not found, retry later
      setTimeout(checkForCaptions, 2000);
    }
  }
  
  // Start checking for captions
  checkForCaptions();
}

// Process caption text
function processCaptionText(text) {
  if (!translationEnabled) return;
  
  console.log('Caption text:', text);
  updateDebugInfo(`Caption: ${text}`);
  
  // Split text into words
  const words = text.toLowerCase().split(/\s+/).filter(word => word.length > 0);
  
  // Process words
  processRecognizedWords(words);
}

// Process recognized words
function processRecognizedWords(words) {
  if (!translationEnabled || words.length === 0) return;
  
  const matchedWords = [];
  const missingWords = [];
  
  // Check each word against available sign language words
  for (const word of words) {
    // Remove punctuation and normalize
    const cleanWord = word.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, '').toLowerCase().trim();
    
    if (cleanWord.length === 0) continue;
    
    if (availableWords.includes(cleanWord)) {
      if (!currentlyProcessingWords.has(cleanWord)) {
        matchedWords.push(cleanWord);
        queueWord(cleanWord);
      }
    } else {
      missingWords.push(cleanWord);
    }
  }
  
  // Send recognized words to background script for processing
  if (matchedWords.length > 0) {
    console.log('Matched words:', matchedWords);
    updateDebugInfo(`Found signs for: ${matchedWords.join(', ')}`);
  }
  
  if (missingWords.length > 0 && showDebug) {
    console.log('Missing sign videos for words:', missingWords);
    updateDebugInfo(`No signs for: ${missingWords.join(', ')}`);
  }
}

// Queue a word for sign language video playback
function queueWord(word) {
  if (!translationEnabled || currentlyProcessingWords.has(word)) return;
  
  // Mark this word as being processed
  currentlyProcessingWords.add(word);
  
  // Add to queue
  videoQueue.push(word);
  console.log(`Queued word: ${word}, Queue length: ${videoQueue.length}`);
  
  // Start processing the queue if not already playing
  if (!isPlaying) {
    processNextVideo();
  }
}

// Load a sign language video
async function loadVideo(word) {
  if (videoCache.has(word)) {
    return videoCache.get(word);
  }
  
  try {
    // Find the correct video file
    const videoPath = await findMatchingVideoFile(word);
    
    if (!videoPath) {
      console.error(`No video found for word: ${word}`);
      return null;
    }
    
    // Create video element
    const video = document.createElement('video');
    video.style.width = '100%';
    video.style.height = '100%';
    video.style.objectFit = 'contain';
    
    // Load the video
    video.src = videoPath;
    video.muted = true;
    video.preload = 'auto';
    
    // Wait for video to be loaded
    await new Promise((resolve, reject) => {
      video.oncanplaythrough = resolve;
      video.onerror = reject;
      
      // Set a timeout in case the video loading hangs
      const timeout = setTimeout(() => {
        video.oncanplaythrough = null;
        video.onerror = null;
        reject(new Error('Video loading timeout'));
      }, 5000);
      
      video.oncanplaythrough = () => {
        clearTimeout(timeout);
        resolve();
      };
    });
    
    // Cache the video
    videoCache.set(word, video);
    return video;
  } catch (error) {
    console.error(`Error loading video for ${word}:`, error);
    return null;
  }
}

// Find the correct video file name for a word
async function findMatchingVideoFile(word) {
  // Try different file name patterns
  const patterns = [
    `${word}.mp4`,
    `${word} .mp4`,
    `${word}- Trim.mp4`,
    `${word.charAt(0).toUpperCase() + word.slice(1)}.mp4`
  ];
  
  for (const pattern of patterns) {
    try {
      const path = chrome.runtime.getURL(`sign_words/${pattern}`);
      const response = await fetch(path, { method: 'HEAD' });
      
      if (response.ok) {
        return path;
      }
    } catch (e) {
      // Continue to next pattern
    }
  }
  
  console.error(`Could not find video file for word: ${word}`);
  return null;
}

// Process the next video in the queue
async function processNextVideo() {
  if (!translationEnabled || videoQueue.length === 0) {
    isPlaying = false;
    return;
  }
  
  isPlaying = true;
  const word = videoQueue.shift();
  
  if (!word) {
    isPlaying = false;
    return;
  }
  
  try {
    // Load the video
    const video = await loadVideo(word);
    
    if (!video) {
      // Remove from processing set
      currentlyProcessingWords.delete(word);
      // Continue with next video
      processNextVideo();
      return;
    }
    
    // Clean container and add video
    if (signLanguageContainer) {
      // Remove any existing videos
      const existingVideos = signLanguageContainer.querySelectorAll('video');
      existingVideos.forEach(v => {
        try {
          v.pause();
          v.remove();
        } catch (e) {
          console.error('Error removing video:', e);
        }
      });
      
      // Add the new video
      signLanguageContainer.appendChild(video);
      
      // Add word label
      const wordLabel = document.createElement('div');
      wordLabel.style.cssText = `
        position: absolute;
        bottom: 10px;
        left: 0;
        right: 0;
        text-align: center;
        color: white;
        font-family: Arial, sans-serif;
        font-size: 16px;
        font-weight: bold;
        text-shadow: 0 0 3px black;
      `;
      wordLabel.textContent = word;
      signLanguageContainer.appendChild(wordLabel);
      
      // Play the video
      video.currentTime = 0;
      
      try {
        await video.play();
        
        // Wait for video to end
        await new Promise(resolve => {
          video.onended = resolve;
        });
      } catch (e) {
        console.error('Error playing video:', e);
      }
      
      // Remove the word label
      try {
        signLanguageContainer.removeChild(wordLabel);
      } catch (e) {
        console.error('Error removing word label:', e);
      }
    }
  } catch (error) {
    console.error(`Error processing video for word ${word}:`, error);
  } finally {
    // Remove from processing set
    currentlyProcessingWords.delete(word);
    
    // Continue with next video
    processNextVideo();
  }
}

// Update debug info
function updateDebugInfo(message) {
  if (!debugInfo || !showDebug) return;
  
  debugInfo.textContent = message;
}

// Ensure proper cleanup when the page is unloaded
window.addEventListener('beforeunload', cleanupResources);

// Reposition the sign language container when the window is resized
window.addEventListener('resize', ensureSignLanguageContainerVisible);

// Check on page load if translation should be enabled
chrome.storage.local.get(['translationEnabled', 'captureMode', 'showDebug'], function(result) {
  if (result.translationEnabled) {
    captureMode = result.captureMode || 'self';
    showDebug = result.showDebug || false;
    startTranslation();
  }
});
window.testSignLanguageContainer = testSignLanguageContainer;