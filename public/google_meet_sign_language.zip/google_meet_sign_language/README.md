# Google Meet Sign Language Translator

A Chrome extension that captures audio from Google Meet calls and translates it into sign language videos in real-time.

## Features

- Captures speech from Google Meet calls and displays corresponding sign language videos
- Supports different capture modes:
  - Translate your own speech
  - Translate others' speech
  - Translate all speech
- Displays sign language videos in a floating container
- Works with Google Meet's built-in captions
- Debug mode to show recognized words and status information
- Multiple word recognition with queue system

## Installation

1. Clone this repository or download as ZIP
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" (toggle in the top right)
4. Click "Load unpacked" and select the extension folder
5. The extension icon should appear in your Chrome toolbar

## Usage

1. Join a Google Meet call
2. Click the extension icon to open the popup
3. Select your preferred capture mode
4. Click "Enable Sign Language Translation"
5. Grant microphone permissions if prompted
6. A sign language video container will appear in the corner of your screen
7. As words are spoken, the corresponding sign language videos will play

## Supported Sign Language Words

The extension includes videos for over 70 common words in sign language, including:

- Common words: "hello", "thank you", "goodbye", "i", "want", "to", "talk", etc.
- Action words: "accept", "adjust", "learn", "memorize", etc.
- Objects and concepts: "bathroom", "birthday", "bird", "doctor", etc.

## Development

This extension is built using standard web technologies:
- HTML/CSS for the popup interface
- JavaScript for speech recognition and video handling
- Chrome Extension APIs for integration with the browser

### Project Structure

- `manifest.json` - Extension configuration
- `popup.html/js` - User interface
- `content.js` - Main script for speech recognition and sign language video display
- `background.js` - Background service worker
- `styles.css` - UI styling
- `sign_words/` - Directory containing sign language videos (.mp4)

## License

This project is for educational purposes only. Sign language videos were sourced from public resources.

## Credits

This extension was developed based on an existing YouTube sign language translator with modifications for Google Meet integration.

## Privacy

This extension only processes audio locally on your device. No audio or speech data is transmitted to any external servers. 