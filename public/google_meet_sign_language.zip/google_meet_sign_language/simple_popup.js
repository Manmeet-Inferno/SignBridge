// Simplified popup script for Sign Language Translator
document.addEventListener('DOMContentLoaded', function() {
  console.log('Popup loaded');
  
  // Get UI elements
  const translateBtn = document.getElementById('translateBtn');
  const statusDiv = document.getElementById('status');
  const testWordBtn = document.createElement('button');
  
  // Add test button
  testWordBtn.textContent = 'Test Word Display';
  testWordBtn.style.marginTop = '10px';
  testWordBtn.style.padding = '8px 12px';
  testWordBtn.style.backgroundColor = '#FFA726';
  testWordBtn.style.color = 'white';
  testWordBtn.style.border = 'none';
  testWordBtn.style.borderRadius = '4px';
  testWordBtn.style.cursor = 'pointer';
  
  document.querySelector('.container').appendChild(testWordBtn);
  
  // Add status details section
  const detailsDiv = document.createElement('div');
  detailsDiv.className = 'info';
  detailsDiv.style.marginTop = '15px';
  detailsDiv.style.padding = '10px';
  detailsDiv.style.backgroundColor = '#E8F5E9';
  detailsDiv.style.borderRadius = '4px';
  detailsDiv.style.fontSize = '12px';
  document.querySelector('.container').appendChild(detailsDiv);
  
  // Show detailed status information
  function updateDetails(message) {
    detailsDiv.textContent = message || 'No status information available';
  }
  
  // Function to show status messages
  function showStatus(message, type) {
    console.log(`Status: ${message} (${type})`);
    statusDiv.textContent = message;
    statusDiv.className = `status ${type}`;
    statusDiv.style.display = 'block';
    
    setTimeout(() => {
      statusDiv.style.display = 'none';
    }, type === 'error' ? 5000 : 3000);
  }
  
  // Function to send messages to content script
  function sendMessage(tabId, message) {
    return new Promise((resolve, reject) => {
      try {
        chrome.tabs.sendMessage(tabId, message, response => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          resolve(response || {success: true});
        });
      } catch (error) {
        reject(error);
      }
    });
  }
  
  // Function to check active tab
  async function getActiveTab() {
    try {
      const tabs = await chrome.tabs.query({active: true, currentWindow: true});
      if (tabs.length === 0) {
        throw new Error('No active tab found');
      }
      return tabs[0];
    } catch (error) {
      console.error('Error getting active tab:', error);
      throw error;
    }
  }
  
  // Check if on Google Meet
  async function checkMeetTab() {
    try {
      const tab = await getActiveTab();
      if (!tab.url.includes('meet.google.com')) {
        showStatus('Please open Google Meet first', 'error');
        updateDetails('This extension only works on Google Meet pages. Please navigate to a Google Meet call and try again.');
        translateBtn.disabled = true;
        testWordBtn.disabled = true;
        return false;
      }
      return tab;
    } catch (error) {
      showStatus('Error checking tab', 'error');
      return false;
    }
  }
  
  // Function to test if content script is working
  async function testContentScript() {
    try {
      const tab = await checkMeetTab();
      if (!tab) return false;
      
      showStatus('Checking extension...', 'info');
      
      try {
        const response = await sendMessage(tab.id, {action: 'checkStatus'});
        console.log('Content script response:', response);
        
        if (response && response.success) {
          showStatus('Extension is working', 'success');
          updateDetails(`Extension is ready. ${response.message || ''}`);
          return true;
        } else {
          showStatus('Extension not responding correctly', 'error');
          updateDetails('The extension is loaded but not responding correctly. Try refreshing the page.');
          return false;
        }
      } catch (error) {
        console.error('Error communicating with content script:', error);
        showStatus('Extension not loaded', 'error');
        updateDetails('Failed to communicate with the extension content script. Try refreshing the page, or reinstalling the extension.');
        return false;
      }
    } catch (error) {
      console.error('Error testing content script:', error);
      showStatus('Error checking extension', 'error');
      return false;
    }
  }
  
  // Toggle translation
  async function toggleTranslation(enable) {
    try {
      const tab = await checkMeetTab();
      if (!tab) return;
      
      showStatus(enable ? 'Enabling translation...' : 'Disabling translation...', 'info');
      
      try {
        const response = await sendMessage(tab.id, {
          action: 'toggleTranslation',
          enabled: enable
        });
        
        console.log('Toggle response:', response);
        
        if (response && response.success) {
          showStatus(enable ? 'Translation enabled' : 'Translation disabled', 'success');
          updateDetails(enable ? 
            'Translation is now active. Sign language videos should appear for recognized words.' : 
            'Translation has been disabled. No sign language videos will be shown.');
          
          // Update button state
          translateBtn.textContent = enable ? 
            'Disable Sign Language Translation' : 
            'Enable Sign Language Translation';
          translateBtn.classList.toggle('enabled', enable);
          
          // Save state
          chrome.storage.local.set({translationEnabled: enable});
        } else {
          const errorMsg = response && response.error ? response.error : 'Unknown error';
          showStatus(`Failed: ${errorMsg}`, 'error');
          updateDetails(`Failed to ${enable ? 'enable' : 'disable'} translation: ${errorMsg}. Try refreshing the page or reinstalling the extension.`);
        }
      } catch (error) {
        console.error('Error toggling translation:', error);
        showStatus(`Error ${enable ? 'enabling' : 'disabling'} translation`, 'error');
        updateDetails(`Communication error: ${error.message}. Try refreshing the page or reinstalling the extension.`);
      }
    } catch (error) {
      console.error('Error in toggle translation:', error);
      showStatus('Error processing request', 'error');
    }
  }
  
  // Test showing a word
  async function testWordDisplay() {
    try {
      const tab = await checkMeetTab();
      if (!tab) return;
      
      const testWords = ['hello', 'thankyou', 'i', 'learn', 'want', 'talk'];
      const randomWord = testWords[Math.floor(Math.random() * testWords.length)];
      
      showStatus(`Testing word: ${randomWord}`, 'info');
      
      try {
        const response = await sendMessage(tab.id, {
          action: 'showWord',
          word: randomWord
        });
        
        if (response && response.success) {
          showStatus(`Test word '${randomWord}' sent`, 'success');
          updateDetails(`Test word '${randomWord}' was sent to the content script. A sign language video should appear on the Google Meet page.`);
        } else {
          showStatus('Failed to show test word', 'error');
          updateDetails('Failed to show the test word. The content script might not be working correctly.');
        }
      } catch (error) {
        console.error('Error showing test word:', error);
        showStatus('Error showing test word', 'error');
        updateDetails(`Error communicating with the content script: ${error.message}. Try refreshing the page.`);
      }
    } catch (error) {
      console.error('Error in test word display:', error);
      showStatus('Error processing request', 'error');
    }
  }
  
  // Button click handlers
  translateBtn.addEventListener('click', function() {
    // Get current state from button class
    const isCurrentlyEnabled = translateBtn.classList.contains('enabled');
    toggleTranslation(!isCurrentlyEnabled);
  });
  
  testWordBtn.addEventListener('click', function() {
    testWordDisplay();
  });
  
  // Check extension status when popup opens
  testContentScript();
  
  // Check current state
  chrome.storage.local.get(['translationEnabled'], function(result) {
    const isEnabled = result.translationEnabled === true;
    
    // Update UI to match stored state
    translateBtn.textContent = isEnabled ? 
      'Disable Sign Language Translation' : 
      'Enable Sign Language Translation';
    translateBtn.classList.toggle('enabled', isEnabled);
    
    updateDetails(isEnabled ? 
      'Translation is currently enabled. Sign language videos should appear for recognized words.' : 
      'Translation is currently disabled. Click the button above to enable it.');
  });
}); 