// Simplified Google Meet Sign Language Translator
console.log('Simple Sign Language Translator loaded');

// Basic variables
let signContainer = null;
let debugDiv = null;
let wordQueue = [];
let isPlaying = false;
let translationActive = false;

// List of available sign language words from videos
const availableWords = [
  'hello', 'thank', 'you', 'thankyou', 'i', 'want', 'to', 'learn', 
  'can', 'talk', 'with', 'my', 'deaf', 'friend', 'this', 'year'
];

// Show debug message (always visible)
function showDebug(message) {
  console.log('Sign Language Debug:', message);
  
  if (!debugDiv) {
    debugDiv = document.createElement('div');
    debugDiv.style.position = 'fixed';
    debugDiv.style.bottom = '10px';
    debugDiv.style.left = '10px';
    debugDiv.style.backgroundColor = 'rgba(0,0,0,0.7)';
    debugDiv.style.color = 'white';
    debugDiv.style.padding = '10px';
    debugDiv.style.borderRadius = '5px';
    debugDiv.style.zIndex = '9999';
    debugDiv.style.fontFamily = 'Arial, sans-serif';
    document.body.appendChild(debugDiv);
  }
  
  debugDiv.textContent = message;
  debugDiv.style.display = 'block';
}

// Create the sign language container
function createSignContainer() {
  if (signContainer) return signContainer;
  
  signContainer = document.createElement('div');
  signContainer.style.position = 'fixed';
  signContainer.style.bottom = '10px';
  signContainer.style.right = '10px';
  signContainer.style.width = '200px';
  signContainer.style.height = '150px';
  signContainer.style.backgroundColor = 'rgba(0,0,0,0.7)';
  signContainer.style.border = '1px solid white';
  signContainer.style.borderRadius = '5px';
  signContainer.style.zIndex = '9999';
  signContainer.style.display = 'flex';
  signContainer.style.justifyContent = 'center';
  signContainer.style.alignItems = 'center';
  
  document.body.appendChild(signContainer);
  return signContainer;
}

// Test the sign video display with a simple word
function testSignDisplay() {
  showDebug('Testing sign video display...');
  
  // Create and show container
  const container = createSignContainer();
  
  // Create video element
  const video = document.createElement('video');
  video.style.maxWidth = '100%';
  video.style.maxHeight = '100%';
  
  // Find a test video
  const testWords = ['hello', 'thankyou', 'i', 'learn'];
  let foundVideo = false;
  
  for (const word of testWords) {
    try {
      const path = chrome.runtime.getURL(`sign_words/${word}.mp4`);
      
      // Test if file exists
      fetch(path, { method: 'HEAD' })
        .then(response => {
          if (response.ok) {
            showDebug(`Found test video for: ${word}`);
            video.src = path;
            video.muted = true;
            container.innerHTML = '';
            container.appendChild(video);
            
            // Add label
            const label = document.createElement('div');
            label.textContent = word;
            label.style.position = 'absolute';
            label.style.bottom = '5px';
            label.style.color = 'white';
            label.style.textAlign = 'center';
            label.style.width = '100%';
            container.appendChild(label);
            
            // Play video
            video.play()
              .then(() => {
                showDebug(`Playing test video for: ${word}`);
                foundVideo = true;
              })
              .catch(err => {
                showDebug(`Error playing video: ${err.message}`);
              });
          }
        })
        .catch(err => {
          console.error(`Error testing ${word}:`, err);
        });
      
      if (foundVideo) break;
    } catch (error) {
      console.error(`Error with ${word}:`, error);
    }
  }
  
  if (!foundVideo) {
    showDebug('Could not find any test videos.');
    
    // Show text fallback
    container.innerHTML = '';
    const textFallback = document.createElement('div');
    textFallback.textContent = 'Test Sign: Hello';
    textFallback.style.color = 'white';
    textFallback.style.textAlign = 'center';
    container.appendChild(textFallback);
  }
}

// Simple event listeners for testing
document.addEventListener('keydown', function(event) {
  // Press 'T' to test the sign display
  if (event.key === 't' || event.key === 'T') {
    showDebug('Manual test triggered (T key)');
    testSignDisplay();
  }
  
  // Press 'C' to clear and remove containers
  if (event.key === 'c' || event.key === 'C') {
    showDebug('Clearing containers (C key)');
    if (signContainer) {
      document.body.removeChild(signContainer);
      signContainer = null;
    }
    if (debugDiv) {
      document.body.removeChild(debugDiv);
      debugDiv = null;
    }
  }
});

// Listen for extension messages
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  showDebug('Received message: ' + request.action);
  
  if (request.action === 'toggleTranslation') {
    if (request.enabled) {
      try {
        // Simple activation test
        translationActive = true;
        showDebug('Translation activated');
        testSignDisplay();
        sendResponse({ success: true });
      } catch (error) {
        showDebug('Error: ' + error.message);
        sendResponse({ success: false, error: error.message });
      }
    } else {
      translationActive = false;
      showDebug('Translation deactivated');
      // Clean up containers
      if (signContainer) {
        document.body.removeChild(signContainer);
        signContainer = null;
      }
      sendResponse({ success: true });
    }
    return true;
  }
  
  // Simple status check
  if (request.action === 'checkStatus') {
    sendResponse({ 
      success: true, 
      active: translationActive,
      message: 'Simple translator is ready'
    });
    return true;
  }
  
  // Basic word display
  if (request.action === 'showWord') {
    showDebug('Showing word: ' + request.word);
    queueWord(request.word);
    sendResponse({ success: true });
    return true;
  }
});

// Test words
function queueWord(word) {
  wordQueue.push(word);
  if (!isPlaying) {
    processNextWord();
  }
}

// Process the next word in the queue
function processNextWord() {
  if (wordQueue.length === 0) {
    isPlaying = false;
    return;
  }
  
  isPlaying = true;
  const word = wordQueue.shift();
  
  // Create container if needed
  const container = createSignContainer();
  
  // Create video element
  const video = document.createElement('video');
  video.style.maxWidth = '100%';
  video.style.maxHeight = '100%';
  
  try {
    const path = chrome.runtime.getURL(`sign_words/${word}.mp4`);
    
    // Test if file exists
    fetch(path, { method: 'HEAD' })
      .then(response => {
        if (response.ok) {
          video.src = path;
          video.muted = true;
          container.innerHTML = '';
          container.appendChild(video);
          
          // Add label
          const label = document.createElement('div');
          label.textContent = word;
          label.style.position = 'absolute';
          label.style.bottom = '5px';
          label.style.color = 'white';
          label.style.textAlign = 'center';
          label.style.width = '100%';
          container.appendChild(label);
          
          // Play video
          video.play()
            .then(() => {
              video.onended = () => {
                isPlaying = false;
                processNextWord();
              };
            })
            .catch(err => {
              showDebug(`Error playing video: ${err.message}`);
              isPlaying = false;
              processNextWord();
            });
        } else {
          showDebug(`Video not found for: ${word}`);
          isPlaying = false;
          processNextWord();
        }
      })
      .catch(err => {
        console.error(`Error loading ${word}:`, err);
        isPlaying = false;
        processNextWord();
      });
  } catch (error) {
    console.error(`Error with ${word}:`, error);
    isPlaying = false;
    processNextWord();
  }
}

// Initial help message
setTimeout(() => {
  showDebug('Sign Language Translator ready - Press T to test video display');
}, 2000);

// Inform that script is loaded
console.log('Simple Sign Language Translator fully loaded');
window.signLanguageTranslatorLoaded = true; 