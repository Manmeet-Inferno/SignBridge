# Troubleshooting Guide for Sign Language Translator

If you're experiencing issues with the Sign Language Translator extension for Google Meet, here are some solutions to common problems:

## "Failed to translate" Error

This error typically occurs when the extension can't initialize properly. Try these steps:

1. **Refresh the Google Meet page** - Sometimes, simply refreshing the page can resolve initialization issues.

2. **Check permissions** - Make sure you've granted microphone permissions to Google Meet:
   - Click the lock icon in the URL bar
   - Ensure "Microphone" is set to "Allow"
   - Refresh the page

3. **Re-enable the extension** - Disable and then re-enable the extension:
   - Click the extension icon
   - Click "Disable Sign Language Translation"
   - Then click "Enable Sign Language Translation" again

4. **Check browser console** - For advanced users:
   - Right-click on the Google Meet page
   - Select "Inspect" or "Inspect Element"
   - Go to the "Console" tab
   - Look for any error messages related to the extension

## No Videos Playing

If the extension appears to be working but no sign language videos are playing:

1. **Check debug info** - Enable debug information in the extension popup to see if words are being recognized.

2. **Test with common words** - Try speaking some of the most common words like "hello," "thank you," "i," "want," etc.

3. **Verify your capture mode** - Make sure you've selected the correct capture mode in the popup:
   - "Translate my speech" - For your own voice
   - "Translate others' speech" - For other participants
   - "Translate all speech" - For all participants

4. **Check browser permissions** - Ensure that your browser is not blocking autoplay videos:
   - Go to chrome://settings/content/sound
   - Make sure Google Meet is not in the "Muted" list

## Extension Not Loading

If the extension doesn't appear to be working at all:

1. **Reinstall the extension** - Remove and reinstall the extension:
   - Go to chrome://extensions/
   - Find "Sign Language Translator for Google Meet"
   - Click "Remove"
   - Reload the extension

2. **Check for conflicts** - Disable other extensions that might be interfering with Google Meet.

3. **Update Chrome** - Make sure you're using the latest version of Chrome.

## Still Having Issues?

If you've tried all these steps and are still experiencing problems:

1. **Check browser console for errors** as described above
2. **Recreate the extension** by running the setup script again
3. **Contact the developer** with details about your specific issue

## Reporting Bugs

When reporting issues, please include:
- The exact error message you're seeing
- Steps to reproduce the problem
- Your browser version
- Any console errors
- What you've already tried from this guide 