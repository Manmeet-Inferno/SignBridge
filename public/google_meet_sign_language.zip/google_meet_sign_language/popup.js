document.addEventListener('DOMContentLoaded', function() {
  const translateBtn = document.getElementById('translateBtn');
  const statusDiv = document.getElementById('status');
  const captureModeSelect = document.getElementById('captureMode');
  const showDebugCheckbox = document.getElementById('showDebug');

  // Function to initialize translation
  async function initializeTranslation(tab) {
    if (!tab.url.includes('meet.google.com')) {
      showStatus('Please navigate to a Google Meet call', 'error');
      return false;
    }

    try {
      // Send message to content script to start translation
      await chrome.tabs.sendMessage(tab.id, {
        action: 'toggleTranslation',
        enabled: true,
        captureMode: captureModeSelect.value,
        showDebug: showDebugCheckbox.checked
      });

      return true;
    } catch (error) {
      console.error('Failed to initialize translation:', error);
      showStatus('Failed to initialize translation. Please refresh the page and try again.', 'error');
      return false;
    }
  }

  // Check current state
  chrome.storage.local.get(['translationEnabled', 'captureMode', 'showDebug'], function(result) {
    if (result.translationEnabled) {
      translateBtn.textContent = 'Disable Sign Language Translation';
      translateBtn.classList.add('enabled');
      showStatus('Translation is active', 'success');
    } else {
      translateBtn.textContent = 'Enable Sign Language Translation';
      translateBtn.classList.remove('enabled');
    }

    // Set saved options
    if (result.captureMode) {
      captureModeSelect.value = result.captureMode;
    }
    
    if (result.showDebug !== undefined) {
      showDebugCheckbox.checked = result.showDebug;
    }
  });

  // Handle button click
  translateBtn.addEventListener('click', async function() {
    const tabs = await chrome.tabs.query({active: true, currentWindow: true});
    const currentTab = tabs[0];

    chrome.storage.local.get(['translationEnabled'], async function(result) {
      const newState = !result.translationEnabled;
      
      if (newState) {
        // Enabling translation
        showStatus('Starting translation...', 'info');
        const success = await initializeTranslation(currentTab);
        if (!success) {
          showStatus('Failed to start translation', 'error');
          return;
        }
      }

      // Save options
      chrome.storage.local.set({
        translationEnabled: newState,
        captureMode: captureModeSelect.value,
        showDebug: showDebugCheckbox.checked
      }, function() {
        // Send message to content script
        chrome.tabs.sendMessage(currentTab.id, {
          action: 'toggleTranslation',
          enabled: newState,
          captureMode: captureModeSelect.value,
          showDebug: showDebugCheckbox.checked
        });

        // Update UI
        translateBtn.textContent = newState ? 
          'Disable Sign Language Translation' : 
          'Enable Sign Language Translation';
        translateBtn.classList.toggle('enabled', newState);
        
        if (newState) {
          showStatus('Translation enabled', 'success');
        } else {
          showStatus('Translation disabled', 'success');
        }
      });
    });
  });

  // Handle option changes
  captureModeSelect.addEventListener('change', function() {
    chrome.storage.local.set({ captureMode: captureModeSelect.value });
    
    // Update active translation if enabled
    chrome.storage.local.get(['translationEnabled'], function(result) {
      if (result.translationEnabled) {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
          chrome.tabs.sendMessage(tabs[0].id, {
            action: 'updateOptions',
            captureMode: captureModeSelect.value,
            showDebug: showDebugCheckbox.checked
          });
        });
      }
    });
  });

  showDebugCheckbox.addEventListener('change', function() {
    chrome.storage.local.set({ showDebug: showDebugCheckbox.checked });
    
    // Update active translation if enabled
    chrome.storage.local.get(['translationEnabled'], function(result) {
      if (result.translationEnabled) {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
          chrome.tabs.sendMessage(tabs[0].id, {
            action: 'updateOptions',
            captureMode: captureModeSelect.value,
            showDebug: showDebugCheckbox.checked
          });
        });
      }
    });
  });

  function showStatus(message, type) {
    statusDiv.textContent = message;
    statusDiv.className = `status ${type}`;
    statusDiv.style.display = 'block';
    if (type === 'error') {
      // Keep error messages visible longer
      setTimeout(() => {
        statusDiv.style.display = 'none';
      }, 5000);
    } else {
      setTimeout(() => {
        statusDiv.style.display = 'none';
      }, 3000);
    }
  }
});